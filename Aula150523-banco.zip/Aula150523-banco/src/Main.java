import javax.swing.JOptionPane;

public class Main {

	public static void main(String[] args) {
		
		Conta conta; // Instanciamento da conta;
		
		//Coleta dos dados;
		String tit = JOptionPane.showInputDialog("Informe o nome do titular:");
		int num = Integer.parseInt(JOptionPane.showInputDialog("Informe o n�mero da conta:"));
		
		
		//Decis�o se h� ou n�o dep�sito inicial e chamada do construtor respectivo;
		char resp = JOptionPane.showInputDialog("H� dep�sito inicial?","(S/N)").toUpperCase().charAt(0);
		if(resp == 'S') {
			double depositoInicial = Double.parseDouble(JOptionPane.showInputDialog("Informe o dep�sito inicial: "));
			conta = new Conta(num, tit, depositoInicial);
		}else {
			conta = new Conta(num, tit);
		}
		
		JOptionPane.showMessageDialog(null, "Dados banc�rios: " + conta );
		
		//Teste de dep�sito: 
		conta.depositar(Double.parseDouble(JOptionPane.showInputDialog("Informe o valor do dep�sito: ")));
		JOptionPane.showMessageDialog(null, "Novos dados banc�rios: " + conta );
		
		//Teste de saque: 
		conta.sacar(Double.parseDouble(JOptionPane.showInputDialog("Informe o valor do dep�sito: ")));
		JOptionPane.showMessageDialog(null, "Novos dados banc�rios: " + conta );

	}

}
