
public class Conta {
	private int num;
	private String titular; 
	private double saldo = 0;
	
	public Conta(){
		
	}
	
	public Conta(int num, String titular) {
		this.num = num;
		this.titular = titular;
	}
	
	public Conta (int num, String titular, double depositoInicial) {
		this.num = num;
		this.titular = titular;
		depositar(depositoInicial);
	}
	
	public void depositar(double valor) {
		this.saldo += valor;
	}
	
	public void sacar(double valor) {
		this.saldo -= valor + 5;
	}
	
	
	public String getTitular() {
		return titular;
	}

	public void setTitular(String titular) {
		this.titular = titular;
	}

	@Override
	public String toString() {
		return "\nN�mero da conta: " + num + ", Titular: " + titular + ", Saldo: R$" + saldo;
	}


	
	//public String toString() {
	//	return "N�mero: " + num + ", Titular: " + titular + ", Saldo: R$" + saldo;
	//}
	
	
	
	
}
