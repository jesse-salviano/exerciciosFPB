import java.util.Scanner;

import javax.swing.JOptionPane;


public class Main {

	public static void main(String[] args) {
		
		Scanner entrada = new Scanner(System.in);
		Aluno aluno1 = new Aluno();
		
		
		String nome = JOptionPane.showInputDialog("Informe o nome do aluno: ");
		//System.out.println("Informe o nome do aluno: ");
		aluno1.setNome(nome);
		
		int idade = Integer.parseInt(JOptionPane.showInputDialog("Informe a idade do aluno: "));
		aluno1.setIdade(idade);
		
		String faculdade = JOptionPane.showInputDialog("Informe a faculdade do aluno: ");
		aluno1.setFaculdade(faculdade);
		
		//DISCIPLINAS
		
		int qtdDisciplinas = Integer.parseInt(JOptionPane.showInputDialog("Informe a quantidade de mat�rias do aluno: "));

		
		for(int i = 0; i < qtdDisciplinas; i++) {
			String disc = JOptionPane.showInputDialog("\nInforme o nome da disciplina " + (i+1) + ": ");
			double nota = Double.parseDouble(JOptionPane.showInputDialog("Informe a nota: "));
			Disciplina disciplina = new Disciplina();
			disciplina.setDisciplina(disc);
			disciplina.setNota(nota);
			aluno1.getDisciplinas().add(disciplina);
		}
		
		JOptionPane.showMessageDialog(null, aluno1);

		entrada.close();
		
	}

}
