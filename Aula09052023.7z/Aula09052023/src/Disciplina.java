
public class Disciplina {
	
	public String disciplina;
	public double nota;

	//Getters e Setters
	
	public double getNota() {
		return nota;
	}
	
	public void setNota(double nota) {
		this.nota = nota;
	}
	public String getDisciplina() {
		return disciplina;
	}
	public void setDisciplina(String disciplina) {
		this.disciplina = disciplina;
	}

	//toString
	
	@Override
	public String toString() {
		return  disciplina + " - Nota: " + nota;
	}
	
}
