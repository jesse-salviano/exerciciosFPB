import java.util.ArrayList;
import java.util.List;

public class Aluno {
	private String nome;
	private int idade;
	private String faculdade; 
	
	List<Disciplina> disciplinas = new ArrayList<>();

	//M�TODOS
	
	public String getNome() {
		return nome;
	}

	public void setNome(String nome) {
		this.nome = nome;
	}

	public int getIdade() {
		return idade;
	}

	public void setIdade(int idade) {
		this.idade = idade;
	}

	public String getFaculdade() {
		return faculdade;
	}

	public void setFaculdade(String faculdade) {
		this.faculdade = faculdade;
	}

	public List<Disciplina> getDisciplinas() {
		return disciplinas;
	}

	public void setDisciplinas(List<Disciplina> disciplinas) {
		this.disciplinas = disciplinas;
	}

	
	public double media(){
		double soma = 0;
		int cont = 0;
	
		
		while (cont < this.disciplinas.size()) {
			soma += disciplinas.get(cont).getNota();
			cont ++;
		}
		
		double media = soma/this.disciplinas.size();
		return media;
	}
	
	public String situacao() {
		return media() >= 7 ? "Aprovado" : "Reprovado";
	}

	@Override
	public String toString() {
		return "Nome: " + nome + "\nIdade: " + idade + "\nFaculdade: " + faculdade + "\nDisciplinas: " + disciplinas
				+ "\nM�dia: " + media() + "\nSitua��o: " + situacao();
	}
	
	

}
